package org.terrier.matching.models;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.terrier.matching.models.Idf;
import org.terrier.matching.models.WeightingModel;
import org.terrier.structures.Index;

import SemanticIR.LoadPathes;
import SemanticIR.MesureZarghayouna;
import SemanticIR.OntologyParser;
import SemanticIR.Similarity;

import com.hp.hpl.jena.ontology.OntClass;

public class SemBM25 extends WeightingModel {

	private double k_1 = 1.2d;
	
	/** model name */
	private static final String name = "BM25WeightingZargayouna";
	
	/** The constant k_3.*/
	private double k_3 = 8d;
	
	/** The parameter b.*/
	private double b;
	
	/** A default constructor.*/
	public SemBM25() {
		super();
		b=0.75d;
	}
	/**
	 * Returns the name of the model.
	 * @return the name of the model
	 */
	public final String getInfo() {
		return name+b;
	}
	


	@Override
	public double score(double tf, double docLength) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double score(double tf, double docLength, double nT, double F_t,
			double keyFrequency) {
		// TODO Auto-generated method stub
		return 0;
	}
	public double score(int tf, int docLength, String term, int MONdocumNum, String PathAnn, Index index, OntologyParser onto/*, HashMap<String, String> OneDocTermConcepts, HashMap<String, Integer> OneDocTermsFreq */ ) throws InterruptedException, IOException, NullPointerException, TransformerException, ParserConfigurationException 
	{
	
		System.out.println("Herrreeeeeeee in SEMBM25 Score");
		MesureZarghayouna mz=new MesureZarghayouna(index, onto);
		double MONTF=mz.PonderationTermInDoc(term, MONdocumNum,  PathAnn);
		
		
		
		System.out.println(" numberOfDocuments ="+numberOfDocuments+" documentFrequency ="+documentFrequency+ " docleght=="+docLength);
		System.out.println("SOM-TF==="+MONTF);
		MONTF+=tf;
		System.out.println("SemIndex Après ajout de TF:"+tf+" est egal =="+MONTF);
		
		double IDF = Idf.log((numberOfDocuments - documentFrequency + 0.5d) / (documentFrequency+ 0.5d));
		System.out.println("IDF=="+IDF);
		double K = k_1 * ((1 - b) + b * docLength / averageDocumentLength) + MONTF;
		
		
		double pond= IDF*((k_1 + 1d) * MONTF / (K + MONTF)) *
				((k_3+1)*keyFrequency/(k_3+keyFrequency));
		
		System.out.println("keyFrequency==FRequence in query "+keyFrequency);
		System.out.println("Score final de ce terme  dans ce doc= "+pond);
		return pond;
		///Faut Lancer le SetKeyFrequency Bien avant pr modifier pondération des termes ds la requete
		
	}
	

	

	
	

}
