/*
 * Terrier - Terabyte Retriever 
 * Webpage: http://terrier.org 
 * Contact: terrier{a.}dcs.gla.ac.uk
 * University of Glasgow - Department of Computing Science
 * http://www.gla.ac.uk/
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is Full.java.
 *
 * The Original Code is Copyright (C) 2004-2010 the University of Glasgow.
 * All Rights Reserved.
 *
 * Contributor(s):
 *   Nicola Tonellotto (original author)
 *   Craig Macdonald <craigm{a.}dcs.gla.ac.uk>
 *   
 */
package org.terrier.matching.taat;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.terrier.matching.AccumulatorResultSet;
import org.terrier.matching.BaseMatching;
import org.terrier.matching.CollectionResultSet;
import org.terrier.matching.MatchingQueryTerms;
import org.terrier.matching.PostingListManager;
import org.terrier.matching.ResultSet;
import org.terrier.structures.Index;
import org.terrier.structures.postings.IterablePosting;

import SemanticIR.LoadPathes;


/** An exhaustive TAAT approach for matching documents to a query.
 * This Matching strategy uses the PostingListManager for opening
 * and scoring postings.
 * @author Nicola Tonellotto, Craig Macdonald
 * @since 3.0
 * @see org.terrier.matching.PostingListManager
 */
public class Full extends BaseMatching
{
	public static String fileProp="/users/ines/Bureau/WorkspaceValentina/TERRIERIR/Documents/chemin.properties";
	Boolean Sem=false;
	/** Create a new Matching instance based on the specified index */
	public Full(Index index) 
	{
		super(index);
		resultSet = new AccumulatorResultSet(collectionStatistics.getNumberOfDocuments());		
	}

	/** {@inheritDoc} */
	@Override
	public String getInfo() 
	{
		return "taat.Full";
	}

	/** posting list manager opens and scores postings */
	PostingListManager plm;
	
	/** {@inheritDoc} 
	 * @throws InterruptedException 
	 * @throws ParserConfigurationException 
	 * @throws TransformerException 
	 * @throws NullPointerException */
	public ResultSet match(String queryNumber, MatchingQueryTerms queryTerms) throws IOException, InterruptedException, NullPointerException, TransformerException, ParserConfigurationException 
	{
		final long starttime = System.currentTimeMillis();
		initialise(queryTerms);
		
		
	/*	QueryExpansion qq=new QueryExpansion();
		for(int i=0; i<queryTerms.getTerms().length;i++)
		{
			qq.expandQuery(queryTerms, queryTerms.getTerms()[i], index, currentDocId, o, ss)
		}*/
		
		
		
		plm = new PostingListManager(index, super.collectionStatistics, queryTerms);
		if (MATCH_EMPTY_QUERY && plm.size() == 0)
		{
			// Check whether we need to match an empty query. If so, then return the existing result set.
			resultSet = new CollectionResultSet(collectionStatistics.getNumberOfDocuments());
			resultSet.setExactResultSize(collectionStatistics.getNumberOfDocuments());
			resultSet.setResultSize(collectionStatistics.getNumberOfDocuments());
			return resultSet;
		}
		//DO NOT prepare the posting lists for TAAT retrieval
		plm.prepare(false);
				
		for(int i=0; i< plm.size(); i++)
		{	if(Sem==true)
			{
	
			assignScores(i, (AccumulatorResultSet) resultSet, plm.getPosting(i),queryTerms );  
	        
			}
			
		else
			assignScores(i, (AccumulatorResultSet) resultSet, plm.getPosting(i));
		}

		resultSet.initialise();
		this.numberOfRetrievedDocuments = resultSet.getExactResultSize();
		finalise(queryTerms);
		if (logger.isDebugEnabled())
			logger.debug("Time to match "+numberOfRetrievedDocuments+" results: " + (System.currentTimeMillis() - starttime) + "ms");
		return resultSet;
	}
	
	protected void assignScores(int i, AccumulatorResultSet rs, final IterablePosting postings, MatchingQueryTerms queryTerms) throws IOException, InterruptedException, NullPointerException, TransformerException, ParserConfigurationException
	{
		LoadPathes ll=new LoadPathes();
	    String PathAnn=ll.getChemin(fileProp, "FileAnnotations");
		int docid;
		double score;
	
		short mask = 0;
		if (i < 16)
			mask = (short)(1 << i);
		
		while (postings.next() != IterablePosting.EOL)
		{
			docid = postings.getId();
			
		
			System.out.println(" WE ARE in this assignscore du FULL if semantique !!!");
			
			
			score = plm.score(i,queryTerms.getTerms()[i],docid, PathAnn );
			
			//logger.info("Docid=" + docid + " score=" + score);
			if ((!rs.scoresMap.contains(docid)) && (score > 0.0d))
				numberOfRetrievedDocuments++;
			else if ((rs.scoresMap.contains(docid)) && (score < 0.0d))
				numberOfRetrievedDocuments--;

			rs.scoresMap.adjustOrPutValue(docid, score, score);
			rs.occurrencesMap.put(docid, (short)(rs.occurrencesMap.get(docid) | mask));
		}
	}
	protected void assignScores(int i, AccumulatorResultSet rs, final IterablePosting postings) throws IOException, InterruptedException, NullPointerException, TransformerException, ParserConfigurationException
	{
		//System.out.println("We are Here in AssignScore De Full");
		
		int docid;
		double score;
	
		short mask = 0;
		if (i < 16)
			mask = (short)(1 << i);
		
		while (postings.next() != IterablePosting.EOL)
		{
			//System.out.println(" WE ARE in this assignscore du FULL if NOTT semantique !!!");
			
			docid = postings.getId();
			score = plm.score(i );
			
			//logger.info("Docid=" + docid + " score=" + score);
			if ((!rs.scoresMap.contains(docid)) && (score > 0.0d))
				numberOfRetrievedDocuments++;
			else if ((rs.scoresMap.contains(docid)) && (score < 0.0d))
				numberOfRetrievedDocuments--;

			rs.scoresMap.adjustOrPutValue(docid, score, score);
			rs.occurrencesMap.put(docid, (short)(rs.occurrencesMap.get(docid) | mask));
		}
	}

	@Override
	protected void initialisePostings(MatchingQueryTerms queryTerms) {
		
	}
}
