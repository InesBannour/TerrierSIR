package Application;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import com.hp.hpl.jena.ontology.OntClass;

import SemanticIR.LoadPathes;

public class BaseDesAnnotations {
	
		static Element racine = new Element("Annotations");
	   //On crée un nouveau Document JDOM basé sur la racine que l'on vient de créer
	   static org.jdom.Document document = new Document(racine);
	  // static String PathXmlFile="/users/ines/Bureau/WorkspaceValentina/TERRIERIR/Documents/Annotations.xml";
	   public static int nbreOfDoc=0;
		public static String fileProp="./Documents/chemin.properties";
	
		public  void Annotate( String PathXmlFile, HashMap<String, HashMap<String, OntClass>> Annotations) throws IOException
	   {
	      //On crée une instance de SAXBuilder
	      SAXBuilder sxb = new SAXBuilder();
	      try
	      {
	         //On crée un nouveau document JDOM avec en argument le fichier XML
	    	  //Le parsing est terminé ;)
	         document = sxb.build(new File(PathXmlFile));
	      }
	      catch(Exception e){}

	      //On initialise un nouvel élément racine avec l'élément racine du document.
	      racine = document.getRootElement();
	      System.out.println("Racine "+racine.toString());

	      //Méthode définie dans la partie 3.2. de cet article
	     WriteDocConcepts(PathXmlFile, Annotations);
	  
	   }
	   
	 //Ajouter cette méthodes à la classe MakeCollection
	   public void  WriteDocConcepts(String PathXml, HashMap<String, HashMap<String, OntClass>> Annotations) throws IOException
	   {
		   
		 Iterator ii =Annotations.keySet().iterator();
		 while (ii.hasNext())
		 {
			 String doc =(String) ii.next();
			 Element docElem = new Element("Document");
			 racine.addContent(docElem);
			 Attribute idd = new Attribute("id",doc);
			 docElem.setAttribute(idd);
			 HashMap<String, OntClass> Concepts =  Annotations.get(doc);
			 Iterator jj=Concepts.keySet().iterator();
			 while(jj.hasNext())
			 {
				 String Term =(String) jj.next();
				 OntClass Concept=Concepts.get(Term);
				 Element elem = new Element("Concept");
				 Attribute termmm=new Attribute("Term",Term);
				 elem.setAttribute(termmm);
				 elem.setText(Concept.toString());
				
				 docElem.addContent(elem);
			 }
			 
		 }
		 affiche();
	     enregistre(PathXml);
		 
	   }
	   
	 //Ajouter ces deux méthodes à notre classe JDOM1
	   static void affiche()
	   {
	      try
	      {
	         //On utilise ici un affichage classique avec getPrettyFormat()
	         XMLOutputter sortie = new XMLOutputter(Format.getPrettyFormat());
	         sortie.output(document, System.out);
	      }
	      catch (java.io.IOException e){}
	   }

	   static void enregistre(String fichier)
	   {
	      try
	      {
	         //On utilise ici un affichage classique avec getPrettyFormat()
	         XMLOutputter sortie = new XMLOutputter(Format.getPrettyFormat());
	         //Remarquez qu'il suffit simplement de créer une instance de FileOutputStream
	         //avec en argument le nom du fichier pour effectuer la sérialisation.
	         sortie.output(document, new FileOutputStream(fichier));
	      }
	      catch (java.io.IOException e){}
	   }
	   
	/*   public static void main(String[] argv) throws IOException
	   {
		    LoadPathes ll=new LoadPathes();
		    BaseDesAnnotations docAnn=new BaseDesAnnotations();
		    docAnn.Annotate(ll.getChemin(fileProp, "FileAnnotations"));
		   
		   
	   }*/
}
