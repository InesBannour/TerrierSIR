package SemanticIR;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Vector;
import java.lang.NullPointerException;

import org.apache.log4j.Logger;

import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.ontology.OntResource;
import com.hp.hpl.jena.ontology.OntTools;
import com.hp.hpl.jena.ontology.OntTools.Path;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.util.iterator.ExtendedIterator;
import com.hp.hpl.jena.util.iterator.Filter;
import com.hp.hpl.jena.vocabulary.OWL;



public class Similarity {
	protected static final Logger logger = Logger.getRootLogger();
	//Attributs
	HashMap<String, String> listppc; //liste des ppac 
	HashMap<String, Integer> listprof; //liste ds profondeur de chaque concept au root
	HashMap<String, String> listprof2ConcetsPPC; //
	HashMap<String, Float> listmesure; // 
	final static double seuil=0.7;
	//constructeur
	public Similarity()
	{
		listppc = new HashMap<String, String>();
		listprof = new HashMap<String, Integer>();
		listprof2ConcetsPPC=new HashMap<String, String>();
		listmesure = new HashMap<String, Float>();
	}
	
	//Méthodes
	
	/*//méthode permettant de déterminer le ppc(c1,c2)
	protected static OntClass ppc(OntModel o, OntClass c1, OntClass c2)
	{
		OntClass pere = OntTools.getLCA(o, c1, c2);
        return pere;
	}*/
	
	//méthode permettant de trouver le chemin le plus court entre 2 concepts
	protected static Path plusCourtChemin(OntologyParser o, OntClass c1, OntClass c2){
		Path p;
		p = OntTools.findShortestPath(o.onto, c1, c2, Filter.any);
		return p;
	}
	
	//méthode permettant de sauvegarder dans listprof la profondeur de chaque concept de l'ontologie par rapport à la racine
	public void getProf(OntologyParser o) throws InterruptedException
	{
		Iterator<OntClass> i = o.onto.listClasses();
		while(i.hasNext()){
		
			OntClass c1 = i.next();
			if(c1.equals(o.owlThing)) this.listprof.put(o.owlThing.getLocalName(),0);
			else{
			OntClass c2 = o.onto.getOntClass(OWL.Thing.getURI());
			//System.out.println(" C1 :  "+c1.toString());
		//	Thread.sleep(2000);
			if(c1 != c2 && c1.getLocalName()!=null){
				Path p = plusCourtChemin(o, c1, (OntClass) c2);
		  
			    if(p!=null)
			    {
			   // logger.info("concept : "+ c1.getLocalName()+" path: "+p);
			   // System.out.println("p.size : "+p.size());
				this.listprof.put(c1.getLocalName(), p.size());
			    }
			
			}
			else /* if(c1.equals(o.onto.getOntClass(OWL.Thing.getURI())))*/
			{
				int profondeur=0;
				this.listprof.put(c1.getLocalName(), profondeur);
				
				}
			}
		}
	}		
		

	//Mesure de similaritié entre deux concept "WU ET PALMER" 
	public float mesureWuEtPalmerCoupleConcepts(float prof, float prof1, float prof2){

			float mesure;
			if(prof==0) mesure=0;
			else
			{
				mesure = (2 * prof)/(prof1 + prof2 +2*prof);
			}
			
		return mesure;
	}
	
	//méthode qui renvoie la profondeur du concept en paramètre 
	public int profondeur(String c){
		int p = 0;
		Iterator it = this.listprof.keySet().iterator();
		while(it.hasNext()){
			String cc = it.next().toString();
			if(cc.equals(c))
				p = this.listprof.get(cc);
		}
		return p;
	}
	
	
	
	public void getSuperClassesOfConcept(OntClass c1, HashMap<OntClass,Integer> ss, Integer l, OntologyParser o)
    {
        
       
		
		System.out.println(c1.getLocalName());
		System.out.println(" C1 has super classess? "+c1.hasSuperClass());
        Integer m;
        if(c1.hasSuperClass())
        {
        	System.out.println(" "+c1.getLocalName().toString()+" Has super classes !!! ");
        	l++;
            ExtendedIterator<OntClass> oo=c1.listSuperClasses();
            
            while(oo.hasNext())
            {
            	
                OntClass vv=oo.next();
               System.out.println(" Une Super Classe : "+vv.toString());
                boolean b=false;
                if(ss.isEmpty())
                        {
                        ss.put(vv,l);
                        }
               
                if(!ss.isEmpty()  )
                {
                	Integer k=null;
                Iterator it=ss.keySet().iterator();   
                while(it.hasNext())
                    {   
                    OntClass concept=(OntClass) it.next();
                    if(!concept.equals(vv) )
                    {
                    continue;
                    }
                    else{
                   
                        b=true;
                        k=ss.get(concept);
                        break;
                       
                    }
                    }
               
                    if(b==false)
                    { 
                        ss.put(vv,l);        
                    }
                    else if(b==true)
                    {
                    	if(k>l)
                    	{ 
                    	ss.remove(vv);
                    	ss.put(vv,l);
                    	}
                    	
                    }
                    if(vv.hasSuperClass())
                    {
                    	l=ss.get(vv);	
                        getSuperClassesOfConcept(vv,ss, l, o);
                    }
                   
                }     
            
            }
           
        }
    }
	
	public OntClass RecherchePPcEntreDeuxConcepts( HashMap<OntClass, Integer> ss1, HashMap<OntClass, Integer> ss2)
	{
	 OntClass PPC=null;
	 HashMap<OntClass,Integer> ramasseNoeudCommun=new HashMap<OntClass,Integer>();
	
	 Iterator<OntClass> J1 = ss1.keySet().iterator();
     while(J1.hasNext())
     {   
         OntClass rr=J1.next();
       
         Iterator<OntClass> K2 = ss2.keySet().iterator();
         while(K2.hasNext())
         {   Integer min;
        	 OntClass yy=K2.next();
        	 if(rr.equals(yy))
        	 {
        	 System.out.print( "("+rr.getLocalName()+", depth "+ss1.get(rr)+")");
        	 System.out.println(" et("+yy.getLocalName()+", depth "+ss2.get(yy)+")");
        	 Integer a1=ss1.get(rr);
        	 Integer a2= ss2.get(rr);
        	 if( a1> a2 ) min=a2;
        	 else min=a1;
             ramasseNoeudCommun.put(rr,min);
             System.out.println(" Une Entrée Au Ramasse= "+rr.getLocalName()+" A pour depth "+ramasseNoeudCommun.get(rr));
            
        	 }
             
             
         }
     }
     
     int cmpt=0;
     Iterator<OntClass> Ramasse = ramasseNoeudCommun.keySet().iterator();
     while(Ramasse.hasNext())
     { 
    	 OntClass ram1=Ramasse.next();
    	 cmpt++;
     }
     System.out.println("Nbre de père commun: "+cmpt);
   
     Iterator<OntClass> Ramasse1 = ramasseNoeudCommun.keySet().iterator();
     int min=1000000;
     OntClass PPCinit=null;
     
     if(cmpt>1)
     {
     while(Ramasse1.hasNext())
     { 
    
    	 OntClass ram1=Ramasse1.next();
    	
    	/// Integer min;
    	 Iterator<OntClass> Ramasse2 = ramasseNoeudCommun.keySet().iterator();
    	 while(Ramasse2.hasNext()  )
         { 
    		 System.out.println("Ramasse 1: "+ram1.getLocalName() );
    		
    		 OntClass ram2=Ramasse2.next();
    		 System.out.println("Ramasse 2: "+ram2.getLocalName() );
    		 if(ram1!=ram2){
    			
    			 Integer var1=ramasseNoeudCommun.get(ram1) ;
    			 Integer var2=ramasseNoeudCommun.get(ram2) ;
    			
    			// System.out.println("Comparaison entre ("+ram1.getLocalName()+","+var1+") et ("+ram2.getLocalName()+","+var2+")");
    			 if(var1>var2 && var2<min){ /*PPC=ram2*/; min=var2;PPCinit=ram2 ;}
    			 else if(var1<var2 && var1<min) { /*PPC=ram1;*/min=var1;PPCinit=ram1 ;}
    			 else if(var1==var2 && var1<min ){
    				Integer a11=ss1.get(ram1);
    				Integer a21=ss2.get(ram1);
    				Integer SommeRam1=a11+a21;
    				Integer a12=ss1.get(ram2);
    				Integer a22=ss2.get(ram2);
    				Integer SommeRam2=a12+a22;
    				
    				if(SommeRam1<SommeRam2)  {PPCinit=ram1;min=var1;}
    				else if(SommeRam1>SommeRam2) {PPCinit=ram2;min=var2;}
    				else if(SommeRam1==SommeRam2)
    				{
    					int prof1=this.listprof.get(ram1.getLocalName());
    					int prof2=this.listprof.get(ram2.getLocalName());
    					if(prof1<prof2)  {PPCinit=ram1; min=var1;}
    					else {PPCinit=ram2; min=var2;}
    					
    				}
    				
    				
    			 	  }
    			 
    		 }
    		/* else
    		 {
    			PPC= 
    		 }*/
         }
     } 
    }
    else
     {
    	 OntClass ram1=null;
    	  while(Ramasse1.hasNext())
    	     { 
    	    	 ram1=Ramasse1.next();
    	    	 min=ramasseNoeudCommun.get(ram1) ;
    	     }
     PPCinit=ram1;
     }
    PPC=PPCinit;
    System.out.println("PPC = "+PPC+" arrivé après "+min+" d'un des concepts");
	return PPC;
		
	}
	
///////////////////Mesure de similarité appliqué seulement à deux concept::///////////////
	
	public float  CalculSimilarite2concepts(OntClass c1, OntClass c2, OntologyParser o) throws InterruptedException
	{
		
				
				
					float Sim=0;
					OntClass PPC=null;
				  Integer ProfondeurConcept1=null;
				  Integer ProfondeurConcept2=null;
				
				  String couple=null;
				  if(!c1.equals(c2) && !c1.equals(o.owlThing) && !c2.equals(o.owlThing) && !c1.equals(null) && !c2.equals(null)){
					  couple =c1.getLocalName()/*.replace("_", " ")*/+";"+c2.getLocalName()/*.replace("_", " ")*/;		
					
					  logger.info("***Recherche ppc("+c1.getLocalName()+", "+c2.getLocalName()+")" );

					  /////SuperClasses Of Concept c1
					  Integer l=0;
					  HashMap<OntClass,Integer> List1=new HashMap<OntClass, Integer>();
					  System.out.println(c1.toString());
                     
					  System.out.println(" C1 has super classess??? "+c1.hasSuperClass());
					  getSuperClassesOfConcept(c1, List1,l,o)    ;
                      
                      
                     
                      
                      List1.put(c1, 0);
                      /////SuperClasses Of Concept c2
                      Integer g=0;
                      HashMap<OntClass, Integer> List2=new HashMap<OntClass, Integer>();
                      getSuperClassesOfConcept(c2, List2,g,o)    ;
                      List2.put(c2, 0);
                     
                      ////AFFIchage SuperclassesOf concept J
                     logger.info("SuperClassesOf "+c1.getLocalName());
                      Iterator<OntClass> l1 = List1.keySet().iterator();
                      while(l1.hasNext())
                      {
                          OntClass rr=l1.next();
                         
                         logger.info(" "+rr.getLocalName()+" depth "+List1.get(rr));
                         // if(rr.getLocalName().equals(null)) List1.remove(rr);
                      }
                 
                      ////AFFIchage SuperclassesOf concept K
                      logger.info("SuperClassesOf "+c2.getLocalName());
                      Iterator<OntClass> k2 = List2.keySet().iterator();
                      while(k2.hasNext())
                      {
                          OntClass ont=k2.next();
                         
                          logger.info(" "+ont.getLocalName()+" depth "+List2.get(ont));
                         // if(ont.getLocalName().equals(null)) List2.remove(ont);
                      }
                      
                      ///////Recherche du PPC des deux Concepts J et k
                      PPC=RecherchePPcEntreDeuxConcepts(List1, List2);
                      OntClass ThigClass=o.onto.getOntClass(OWL.Thing.getURI());
                     
                      if(PPC==null)
                      {PPC=ThigClass;
                      logger.info(" PPC=THING "+PPC);
                      }
                      ////Recherche profondeur du concept J au PPc, et du cpncept K au Ppc
                      				
                      	ProfondeurConcept1=List1.get(PPC); logger.info(" Profondeur ds du concept 1 au PPC "+ProfondeurConcept1);
                      	ProfondeurConcept2=List2.get(PPC); logger.info(" Profondeur ds du concept 2 au PPC "+ProfondeurConcept2);
                      	logger.info(" Profondeur du concept père "+PPC+ " est "+ this.listprof.get(PPC.getLocalName()));
                      	///Calcul de similarité entre ces deux concepts
                      	Sim=mesureWuEtPalmerCoupleConcepts(this.listprof.get(PPC.getLocalName()),ProfondeurConcept1 ,ProfondeurConcept2);                     				
                      	logger.info("PPAC = "+PPC);
                      	logger.info("Similarité = "+Sim);
                      				
			     }	
				else if(!c1.equals(c2) && (c1.equals(o.owlThing) || c2.equals(o.owlThing)))
				{
					OntClass ThigClass=o.onto.getOntClass(OWL.Thing.getURI());
                    PPC=ThigClass;
					Sim=0;
					logger.info("ICI mesure avec le thing :;: "+Sim);
					Thread.sleep(100);
				}else if(c1.equals(c2))
				{		
					Sim=1;
				}
				else if(c1.equals(o.owlThing) && c2.equals(o.owlThing))
				{
					Sim=0;
				}
				else if(c1.equals(null)||c2.equals(null))
						{
					Sim=0;
						}
      return Sim;				
                 	
	}///end methode
	
	
	
}
			
