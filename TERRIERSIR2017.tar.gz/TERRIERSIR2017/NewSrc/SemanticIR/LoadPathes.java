package SemanticIR;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import com.hp.hpl.jena.ontology.OntModel;

public class LoadPathes {
	
	///charger les pathes du fichier .properties
	
	public String getChemin(String fichprop, String label){		
		Properties prop = new Properties();
		FileInputStream in=null;
		try {
			in = new FileInputStream(fichprop);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			prop.load(in);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String chemin = prop.getProperty(label);
		return chemin;
	}
	public String setChemin(String fichprop, String label, String Valeur) throws IOException{		
		Properties prop = new Properties();
		FileInputStream in=null;
		try {
			in = new FileInputStream(fichprop);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			prop.load(in);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String chemin = (String) prop.setProperty(label,Valeur);
		/*FileWriter gg=new FileWriter(fichprop);
		BufferedWriter bw = new BufferedWriter (gg);
		PrintWriter fichierSortie = new PrintWriter (bw);
		fichierSortie.println("onto="+prop.getProperty(label));*/
		System.out.println("Property of "+ label +" "+prop.getProperty(label));
		
		return prop.getProperty(label);
	}

}
